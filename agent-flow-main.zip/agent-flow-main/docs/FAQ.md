# FAQ

## Table of Contents

- [Where's the name DeerFlow come from?](#wheres-the-name-deerflow-come-from)

- [Which models does DeerFlow support?](#which-models-does-deerflow-support)

## Where's the name DeerFlow come from?

DeerFlow is short for **D**eep **E**xploration and **E**fficient **R**esearch **Flow**. It is named after the deer, which is a symbol of gentleness and elegance. We hope DeerFlow can bring a gentle and elegant deep research experience to you.

## Which models does DeerFlow support?

Please refer to the [Configuration Guide](configuration_guide.md) for more details.
